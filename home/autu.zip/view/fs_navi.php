<?php

?>

<a href="<?=base_url() ?>" style="text-decoration: none;">
	<div class="logo">
		<lable>Koperasi</lable><lable style="color:#138ac9;"> OBS</lable>
	</div>
</a>

<div class="core">
	<?php include_once 'controler/navigasi.php'; ?>
</div>

<div class="cright">
	&copy; Rumah Produktif 2021
</div>
