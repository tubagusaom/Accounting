<body>
		<input id="hide_nav" type="checkbox" name="aa" value="">
		<div id="navi">
			<?php  include_once 'fs_navi.php';  ?>
		</div>
		<div id="container">
			<?php include_once 'fs_container.php'; ?>
		</div>
</body>
