<ul>
	<label for="wiz">
		<li><i class="fa fa-list-alt"></i>Navigasi</li>
	</label>
	<input type="checkbox" id="wiz" name="rad" value="">
		<ul id="n_wiz">
			<li onclick="navi('Navigasi','conten','view/form_build_navi','label=haloo');"><i class="fa fa-angle-double-right"></i>Build</li>
			<li onclick="navi('USER','conten','module/department/view/tambah_dept','label=haloo');"><i class="fa fa-angle-double-right"></i>Parent</li>
			<li><i class="fa fa-angle-double-right"></i>Child</li>
		</ul>
</ul>
