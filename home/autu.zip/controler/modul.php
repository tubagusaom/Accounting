<?php
		for ($i=0; $i < count($_MODULE) ; $i++) {
				include "module/".$_MODULE[$i]."/controler/modul.php";
		}
 ?>
