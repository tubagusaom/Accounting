<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

Class account {

  public function account_xxx(){
    return "account_xxx";
  }

}
// $this_modul_ = new account();
// echo "string";
