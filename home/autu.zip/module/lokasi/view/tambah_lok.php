<form  action="?Proses-Tambah-Lokasi" method="post" class="form_input">
	<table>
		<tr>
			<td colspan="2"><h1>Tambah Lokasi</h1></td>
		</tr>
		<tr>
			<td>Nama Lokasi</td>
			<td>
				<input type="text" name="nama" value="" placeholder="max 20 character">
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<input type="submit" name="simpan" value="Simpan">
			</td>
		</tr>
	</table>
</form>
